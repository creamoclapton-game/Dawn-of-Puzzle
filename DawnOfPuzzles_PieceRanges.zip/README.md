
# 🌅 Dawn of Puzzles (Piece Ranges Edition)

Now with three difficulty tiers and custom piece counts:
- **Beginner:** 10–50 pieces
- **Intermediate:** 50–300 pieces
- **Hard:** 300–1000 pieces

Uses a smart grid that matches the canvas aspect ratio so pieces stay readable—even at high counts. Touch controls, local highscores (per piece count), PWA offline support, seasonal themes, and AI prompt ideas are included.

**Note:** 700–1000 pieces will stress mobile GPUs/CPUs. Modern phones handle it, but drag operations may be slower. Tip: reduce Safari tabs and enable Low Power Mode off for best performance.

Deploy steps are the same as before (Itch.io/Pages).

MIT License.
